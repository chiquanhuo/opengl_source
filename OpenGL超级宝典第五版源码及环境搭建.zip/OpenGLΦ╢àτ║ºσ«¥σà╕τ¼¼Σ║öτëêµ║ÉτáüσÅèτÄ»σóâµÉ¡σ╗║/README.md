# oglsuperbible5
Automatically exported from code.google.com/p/oglsuperbible5

### note 2015-8-21
```
start learning form <OpenGL super bible 5>
I find this source on code.google
but this repository only has chapter01 for Xcode
maybe will update other chapters for Xcode later ^_^
```
